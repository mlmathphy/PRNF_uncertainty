import sys
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

# def pdf_inv_sin_gauss(xmesh):
#     Ns = 1000000
#     x = np.random.rand(Ns)
#     Fx = np.sin(2 * np.pi * x)
#     epi = np.random.normal(0, 0.15, Ns)
#     yx = Fx + epi
#     idx



xmesh = np.linspace(0,1,1001)

Ns = 10000000
x = np.random.rand(Ns)
epi = np.random.normal(0, 0.15, Ns)
Fx = 4.0*(x-0.5)**2
yx = Fx + epi
idx_06 = np.where(np.abs(yx-0.6)<=0.001)[0]
idx_08 = np.where(np.abs(yx-0.8)<=0.001)[0]
idx_1 = np.where(np.abs(yx-1.0)<=0.001)[0]


kernel_08 = stats.gaussian_kde(x[idx_08])
pdf_08 = kernel_08(xmesh)

plt.figure()
plt.plot(xmesh,pdf_08)
plt.grid()        
plt.savefig('pdf08.png', bbox_inches="tight", dpi=300)
