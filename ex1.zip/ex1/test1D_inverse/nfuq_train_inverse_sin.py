import torch
import torch.nn as nn
import numpy as np
import torch.optim as optim
import scipy.integrate as integrate
import matplotlib.pyplot as plt
import math
from scipy import stats
import scipy.special as special
from scipy.stats import gamma
from scipy.stats import cauchy
from scipy.stats import norm
import os

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device',device)

root_output = 'output/'   # where to save trained models
root_data = 'data/initial/'      # where the datasets are

data = None
data_name = None

seed = 12345
torch.manual_seed(seed)
np.random.seed(seed)

def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """
    if not os.path.exists(folder):
        os.makedirs(folder)


def jacobian(output, input):

    n, dim= input.shape
    d = int(dim/2)
    w = torch.ones_like(input[:,[0]])

    jacob1 = torch.empty(d, n, 2 * d)
    input1 = input
    output1 = output[:, d:2 * d]
    for i in range(d):
        output1_i = output1[:, [i]]
        jacob1[i] = torch.autograd.grad(output1_i, input1, w, create_graph=True)[0]

    jacob1 = jacob1.permute(1, 0, 2)
    jacob1 = jacob1[:,:,d:2 * d]
    return jacob1



def save_model(model, model_name):
    """
    Save pytorch NN model.
    """

    savedir = root_output
    make_folder(savedir)

    filename = model_name
    checkpoint = {'state_dict': model.state_dict()}
    torch.save(checkpoint, savedir + filename + '.pt')




class NF_Net(nn.Module):

    def __init__(self, dim):
        super(NF_Net, self).__init__()

        self.dim = dim
        self.hid_size = 256

        self.input = nn.Linear(2 * self.dim, self.hid_size)
        self.fc1= nn.Linear(self.hid_size,self.hid_size)
        self.output = nn.Linear(self.hid_size,self.dim)

        self.inv_input = nn.Linear(2 * self.dim, self.hid_size)
        self.inv_fc1= nn.Linear(self.hid_size,self.hid_size)
        self.inv_output = nn.Linear(self.hid_size,self.dim)


    def forward(self, x):

        y0 = x[:, 0: dim]
        x = torch.tanh(self.input(x))
        x = torch.tanh(self.fc1(x))
        x = self.output(x)
        x = torch.cat((y0, x), 1)
        return x


    def backward(self, x):

        y0 = x[:, 0: dim]
        x = torch.tanh(self.inv_input(x))
        x = torch.tanh(self.inv_fc1(x))
        x = self.inv_output(x)
        x = torch.cat((y0, x), 1)
        return x


    def get_grad(self, x):
     
        x.requires_grad_(True)
        xx = self.forward(x)
        jac = jacobian(xx,x)
        return jac


def standard_normal_logprob(z):
    logZ = -0.5 * math.log(2 * math.pi)
    return logZ - z.pow(2) / 2

def loss_fun(model, y, dim, C_rev):

    NF = model.to(device)
    z = NF.forward(y)

    ## loss1: forward loss:
    loss1 = - 1.0 * torch.mean( torch.sum(standard_normal_logprob(z[:,dim:2*dim]), axis = 1, keepdim=False), axis = 0 )

    ## loss2: det of jacobian
    jac = torch.abs(torch.linalg.det(NF.get_grad(y)))
    loss2 = -1.0 * torch.mean(torch.log(jac))

    ## loss3: backward loss
    y_pred = NF.backward(z)
    loss3 = torch.mean( (y_pred[:,dim:2*dim] - y[:,dim:2*dim])**2 )

    # print(loss1, loss2, loss3)
    loss = loss1 * 1.0 + loss2 * 1.0 + loss3 * C_rev

    return loss


def uni_fun(Ns, example, noise):    ## define y = F(x) + \epsilon

    x = np.random.rand(Ns)

    ## deterministic function F(x)
    if example == "square":
        Fx = 4.0*(x-0.5)**2

    elif example == "sin":
        Fx = np.sin(2 * np.pi * x)

    else:
        Fx = x

    ## noise
    if noise == "gaussian_homo":
        epi = np.random.normal(0, 0.15, Ns)

    elif noise == "gaussian_heter":
        epi = np.random.normal(0, 0.2 * np.abs(Fx), Ns)

    elif noise == "laplace_homo":
        epi = np.random.laplace(0, 0.1, Ns)

    elif noise == "laplace_heter":
        epi = np.random.laplace(0, 0.15 * np.abs(Fx), Ns)

    elif noise == "cauchy_homo":
        epi = cauchy.rvs( size=Ns)

    else:
        print("no noise")
        epi = 0.0
    
    yx = Fx + epi

    plt.cla()
    plt.scatter(yx,x,s=0.1)
    plt.vlines(x = -0.5, ymin = 0, ymax = 1,
           colors = "0.5",linestyle='dashed',
           label = 'vline_multiple - full height')
    plt.vlines(x = 0.0, ymin = 0, ymax = 1,
           colors = "0.5",linestyle='dashed',
           label = 'vline_multiple - full height')
    plt.vlines(x = 0.5, ymin = 0, ymax = 1,
           colors = "0.5",linestyle='dashed',
           label = 'vline_multiple - full height')
    plt.ylim([0, 1])
    plt.xlabel("observation $y$",fontsize=22)
    plt.ylabel("parameter $x$",fontsize=22)
    plt.tick_params(axis='both', which='major', labelsize=20)

    # plt.grid()        
    # plt.legend(['F(x)', 'noise'],fontsize = 20,loc = 'upper right')
    plt.savefig(savedir + 'traindata.png', bbox_inches="tight", dpi=500)
    exit()
    y = np.stack((yx, x), axis=-1)  # inverse problem y is input and x is output
    mu = y.mean(axis=0)
    s = y.std(axis=0)

    return y, mu, s




def test_fun(Ns, example, noise): ## test function 

    y0 = 0.8
    print("test point is ", y0)

    y = y0 * np.ones(Ns)

    return y, y0




# ------------------------------------------------
#                The main routine
# ------------------------------------------------
plt.figure()

C_rev = 50

# The index of the function
example = "sin"
noise = "gaussian_homo"

print(example + noise)


# The dimension of input parameterspace
dim = 1
# The number of testing set
NTest = 20000
# The number of training set
NTrain = 40000
#


savedir = 'trainresult/' + example + '_' + noise + '/'
make_folder(savedir)


y_train0, mu, std = uni_fun(NTrain, example, noise)


static_name = 'data/' + example + '_' + noise + '_mean_std.npy'
with open(static_name, 'wb') as f:
    np.save(f, mu)
    np.save(f, std)

y_train0 = (y_train0 - mu)/std
y_train = torch.as_tensor(y_train0,dtype=torch.float,device = device)


NF = NF_Net(dim).to(device)
NF.zero_grad()
# Learning rate
learning_rate = 0.005
optimizer = optim.Adam(NF.parameters(), lr=learning_rate)
n_iter = 30000

## validation data
y_v0, x0 = test_fun(NTest, example, noise)

y_v0 = (y_v0 - mu[0])/std[0]
y0 = y_v0
z = np.random.randn(NTest,1)
y0_z = np.column_stack((y0,z))
y0_z = torch.as_tensor(y0_z,dtype=torch.float,device = device)


## error record
for i in range(n_iter):
    optimizer.zero_grad()

    if i > 500:
        optimizer.param_groups[0]["lr"] = 0.001

    if i > 2000:
        optimizer.param_groups[0]["lr"] = 0.00005

    if i > 4000:
        optimizer.param_groups[0]["lr"] = 0.00002


    if i % 100 == 0:
        print('iteration step: ' + '{0:1d}'.format(i))

        loss = loss_fun(NF, y_train, dim, C_rev)
        print(loss)

        ## validation dataset test
        y0_y = NF.backward(y0_z)
        y = y0_y[:,dim:2 * dim]
        y_pred = y.to('cpu').detach().numpy().flatten()
        y_pred = std[1] * y_pred + mu[1]

        
        plt.cla()
        ax = plt.hist(y_pred, density='true', bins=50)

        plt.xlabel('x',fontsize=23)
        # plt.ylim(0,0.2)
        plt.ylabel('density of noise',fontsize=23)
        plt.xticks(fontsize=20)
        plt.yticks(fontsize=20)
        plt.grid()        
        # plt.legend(['noise samples'],fontsize = 20,loc = 'upper right')
        plt.savefig(savedir + '/img_' + str(x0) + str(i) + '.png', bbox_inches="tight")

        
    else:
        loss = loss_fun(NF, y_train, dim, C_rev)
    
    loss.backward()
    optimizer.step()


model_name = example + '_' + noise
save_model(NF, model_name)



exit()






















