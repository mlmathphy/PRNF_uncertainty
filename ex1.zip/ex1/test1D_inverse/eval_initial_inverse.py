import sys
import numpy as np
import os
import torch
import matplotlib.pyplot as plt
from numpy import matlib
import torch.nn as nn
import scipy.integrate as integrate
from scipy.stats import norm
from scipy.stats import laplace
from scipy import stats

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device',device)


# set paths
root_output = 'output/'   # where to save trained models
root_results = 'eval_result/'  # folder where to save results
root_data = 'data/initial/'       # where the datasets are

data = None
data_name = None


def load_test_data(name):
    """
    Loads the dataset. Has to be called before anything else.
    :param name: string, the dataset's name
    """
    # normalization
    static_name = 'data/' + name + '_mean_std.npy'
    with open(static_name, 'rb') as f:
        mu = np.load(f)
        s = np.load(f)


    assert isinstance(name, str), 'Name must be a string'
    global data,  data_name
    num_sample = 40000
    if data_name == name:
        return

    elif name == 'sin_gaussian_homo':
        x0 = np.array([0.6,0.8,1.0])
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    elif name == 'square_gaussian_homo':
        x0 = np.array([0.2,0.5,0.8])
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    else:
        raise ValueError('Unknown dataset')
    
    data = x
    data_name = name



def is_data_loaded():
    """
    Checks whether a dataset has been loaded.
    :return: boolean
    """
    return data_name is not None



def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)




def load_checkpoint(filepath, dim):
    """
    Load checkpoint
    """
    checkpoint = torch.load(filepath)
    model = NF_Net(dim).to(device)
    model.load_state_dict(checkpoint['state_dict'])
    return model


def load_model(dim, model_name):
    """
    Load model
    """

    assert is_data_loaded(), 'Dataset hasn\'t been loaded'

    savedir = root_output
    filename = model_name

    print(savedir + filename + '.pt')
    device = torch.device("cuda")
    model = load_checkpoint(savedir + filename + '.pt', dim)
    model.to(device)
    model.eval()
    return model


def pdf_inv_square_gauss():
    xmesh = np.linspace(0,1,1001)

    Ns = 20000000
    x = np.random.rand(Ns)
    epi = np.random.normal(0, 0.15, Ns)
    Fx = 4.0*(x-0.5)**2
    yx = Fx + epi
    idx_06 = np.where(np.abs(yx-0.2)<=0.001)[0]
    idx_08 = np.where(np.abs(yx-0.5)<=0.001)[0]
    idx_1 = np.where(np.abs(yx-0.8)<=0.001)[0]
    kernel_06 = stats.gaussian_kde(x[idx_06])
    kernel_08 = stats.gaussian_kde(x[idx_08])
    kernel_1 = stats.gaussian_kde(x[idx_1])
    pdf_06 = kernel_06(xmesh)
    pdf_08 = kernel_08(xmesh)
    pdf_1 = kernel_1(xmesh)
    return xmesh, pdf_06, pdf_08, pdf_1


class NF_Net(nn.Module):

    def __init__(self, dim):
        super(NF_Net, self).__init__()

        self.dim = dim
        self.hid_size = 256

        self.input = nn.Linear(2 * self.dim, self.hid_size)
        self.fc1= nn.Linear(self.hid_size,self.hid_size)
        self.output = nn.Linear(self.hid_size,self.dim)

        self.inv_input = nn.Linear(2 * self.dim, self.hid_size)
        self.inv_fc1= nn.Linear(self.hid_size,self.hid_size)
        self.inv_output = nn.Linear(self.hid_size,self.dim)


    def backward(self, x, dim):

        y0 = x[:, 0: dim]
        x = torch.tanh(self.inv_input(x))
        x = torch.tanh(self.inv_fc1(x))
        x = self.inv_output(x)
        x = torch.cat((y0, x), 1)
        return x



def test_initialGreen(name):

    savedir = 'evalresult/' + name + '/'
    make_folder(savedir)

    print('initial distribution is {0}...'.format(name))
    load_test_data(name)

    dim = 1
    print('dimensionality is ', dim)
    try:
        NF = load_model(dim, name)

    except IOError:
        return 'N/A'

    static_name = 'data/' + name + '_mean_std.npy'
    with open(static_name, 'rb') as f:
        mu = np.load(f)
        std = np.load(f)

    ## test:
    N_test, N_point = data.shape ## note all data has been normalized
    z_sample0 = np.random.randn(N_test,dim)


    xmesh, pdf_06, pdf_08, pdf_1 = pdf_inv_square_gauss()

    fig, ax = plt.subplots(1, 3,figsize=(15, 4))
    ax[0].plot(xmesh,pdf_06,label='exact', linewidth=3)
    ax[1].plot(xmesh,pdf_08,label='exact', linewidth=3)
    ax[2].plot(xmesh,pdf_1,label='exact', linewidth=3)
    for i in range(N_point):

        y0 = data[:,i]
        y0z_sample0 = np.column_stack( (y0,z_sample0) )

        y0z_sample = torch.as_tensor(y0z_sample0,dtype=torch.float,device = device)
        y0_y = NF.backward(y0z_sample, dim)
        y = y0_y[:,dim:2 * dim]
        y_pred = y.to('cpu').detach().numpy()   # approximation
        y_pred = std[1] * y_pred + mu[1]

        xmesh = np.linspace(0,1,1001)
        # print(y_pred.shape)
        # exit()
        kernel = stats.gaussian_kde(y_pred.flatten())
        pdf = kernel(xmesh)
        ax[i].plot(xmesh, pdf,label='PR-NF', linewidth=3)

        ax[i].legend(loc='best',fontsize=16)
        ax[i].set_xlabel('$x$',fontsize=22)
        ax[i].set_ylabel('$p(x|y)$',fontsize=22)
        ax[i].tick_params(axis='both', which='major', labelsize=20)
        ax[i].set_ylim(0,3.5)
        ax[2].legend(loc='upper center',fontsize=16)
        if i == 0:
            ax[i].set_ylim(0,2.5)
        ax[i].set_xlim(0,1)
        # ax[i].set_yticks(fontsize=18)
     
    plt.subplots_adjust(hspace=0.35)
    plt.subplots_adjust(wspace=0.3)   
    plt.savefig(savedir + 'inverse' + name + '.pdf', bbox_inches="tight")


def main():


    for initial in sys.argv[1:]:

        if initial == 'sin_gaussian_homo':
            test_initialGreen(initial)


        elif initial == 'square_gaussian_homo':
            test_initialGreen(initial)

        else:
            print('{0} is not a test initial'.format(initial))
            continue


if __name__ == '__main__':
    main()
