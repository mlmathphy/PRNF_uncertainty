import sys
import numpy as np
import os
import torch
import matplotlib.pyplot as plt
from numpy import matlib
import torch.nn as nn
from scipy import stats
import scipy.integrate as integrate
from scipy.stats import norm
from scipy.stats import laplace

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device',device)


# set paths
root_output = 'output/'   # where to save trained models
root_results = 'eval_result/'  # folder where to save results
root_data = 'data/initial/'       # where the datasets are

data = None
data_name = None
data0 = None

def load_test_data(name):
    """
    Loads the dataset. Has to be called before anything else.
    :param name: string, the dataset's name
    """
    # normalization
    static_name = 'data/' + name + '_mean_std.npy'
    with open(static_name, 'rb') as f:
        mu = np.load(f)
        s = np.load(f)


    assert isinstance(name, str), 'Name must be a string'
    global data,  data_name, data0
    num_sample = 20000
    if data_name == name:
        return

    elif name == 'sin_gaussian_homo':
        x0 = np.linspace(-0.9,1.9, num = 31)
        x00 = x0
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)


    elif name == 'sin_gaussian_heter':
        x0 = np.linspace(-0.9,1.9, num = 31)
        x00 = x0
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)


    elif name == 'square_gaussian_homo':
        x0 = np.linspace(-0.9,1.9, num = 31)
        x00 = x0
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    elif name == 'square_gaussian_heter':
        x0 = np.linspace(-0.9,1.9, num = 31)
        x00 = x0
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    elif name == 'sin_laplace_homo':
        x0 = np.linspace(-0.9,1.9, num = 31)
        x00 = x0
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    elif name == 'sin_laplace_heter':

        x0 = np.linspace(-0.9,1.9, num = 31)
        print(x0)
        x00 = x0
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    elif name == 'square_laplace_homo':
        x0 = np.linspace(-0.9,1.9, num = 31)
        x00 = x0
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    elif name == 'square_laplace_heter':
        x0 = np.linspace(-0.9,1.9, num = 31)
        x00 = x0
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    else:
        raise ValueError('Unknown dataset')
    
    data = x
    data0 = x00
    data_name = name



def is_data_loaded():
    """
    Checks whether a dataset has been loaded.
    :return: boolean
    """
    return data_name is not None



def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)




def load_checkpoint(filepath, dim):
    """
    Load checkpoint
    """
    checkpoint = torch.load(filepath)
    model = NF_Net(dim).to(device)
    model.load_state_dict(checkpoint['state_dict'])
    return model


def load_model(dim, model_name):
    """
    Load model
    """

    assert is_data_loaded(), 'Dataset hasn\'t been loaded'

    savedir = root_output
    filename = model_name

    print(savedir + filename + '.pt')
    device = torch.device("cuda")
    model = load_checkpoint(savedir + filename + '.pt', dim)
    model.to(device)
    model.eval()
    return model




class NF_Net(nn.Module):

    def __init__(self, dim):
        super(NF_Net, self).__init__()

        self.dim = dim
        self.hid_size = 256

        self.input = nn.Linear(2 * self.dim, self.hid_size)
        self.fc1= nn.Linear(self.hid_size,self.hid_size)
        self.output = nn.Linear(self.hid_size,self.dim)

        self.inv_input = nn.Linear(2 * self.dim, self.hid_size)
        self.inv_fc1= nn.Linear(self.hid_size,self.hid_size)
        self.inv_output = nn.Linear(self.hid_size,self.dim)


    def backward(self, x, dim):

        y0 = x[:, 0: dim]
        x = torch.tanh(self.inv_input(x))
        x = torch.tanh(self.inv_fc1(x))
        x = self.inv_output(x)
        x = torch.cat((y0, x), 1)
        return x


def true_fun(Ns, example, noise, x):    ## define y = F(x) + \epsilon

    ## deterministic function F(x)
    if example == "square":
        Fx = 4.0*(x-0.5)**2

    elif example == "sin":
        Fx = np.sin(2 * np.pi * x)

    else:
        Fx = x

    ## noise
    if noise == "gaussian_homo":
        epi = np.random.normal(0, 0.15, Ns)

    elif noise == "gaussian_heter":
        epi = np.random.normal(0, 0.2 * np.abs(Fx), Ns)

    elif noise == "laplace_homo":
        epi = np.random.laplace(0, 0.1, Ns)

    elif noise == "laplace_heter":
        epi = np.random.laplace(0, 0.15 * np.abs(Fx), Ns)

    else:
        print("no noise")
        epi = 0.0
    
    yx = Fx + epi
    return yx




def test_initialGreen(name, example, noise):

    savedir = 'evalresult/' + name + '/'
    make_folder(savedir)

    print('initial distribution is {0}...'.format(name))
    load_test_data(name)
    dim = 1
    print('dimensionality is ', dim)
    try:
        NF = load_model(dim, name)

    except IOError:
        return 'N/A'

    static_name = 'data/' + name + '_mean_std.npy'
    with open(static_name, 'rb') as f:
        mu = np.load(f)
        std = np.load(f)

    ## test:
    N_test, N_point = data.shape ## note all data has been normalized
    z_sample0 = np.random.randn(N_test,dim)

    fx_pred = np.zeros(N_point)
    plt.figure()
    plt.cla()

    kl_loss = np.zeros(N_point) 
    for i in range(N_point):

        y0 = data[:,i]
        Ns = y0.shape[0]
        y0z_sample0 = np.column_stack( (y0,z_sample0) )

        y0z_sample = torch.as_tensor(y0z_sample0,dtype=torch.float,device = device)
        y0_y = NF.backward(y0z_sample, dim)
        y = y0_y[:,dim:2 * dim]
        y_pred = y.to('cpu').detach().numpy()   # approximation
        y_pred = std[1] * y_pred + mu[1]

        y_true = true_fun(Ns, example, noise, matlib.repmat(data0[i], Ns, 1).flatten())


        xl,xr = np.min(y_true),np.max(y_true)
        x_kl = np.linspace(xl,xr, 1000)
        # print(y_true.shape)
        # exit()
        kernel_truth = stats.gaussian_kde(y_true, bw_method=0.2)
        kernel_pred = stats.gaussian_kde(y_pred.flatten(), bw_method=0.2)
        kl_loss[i] = np.sum( kernel_truth(x_kl)*(x_kl[1]-x_kl[0]) * np.log(  (kernel_truth(x_kl) + 1e-16) /  ( kernel_pred(x_kl) + 1e-16)  ) )
    
    print(kl_loss)
    plt.figure()
    plt.cla()
    plt.plot(data0,kl_loss)
    plt.xlim([-1,2])
    plt.xticks(fontsize=14)
    plt.tick_params(left = False, labelleft = False)
    plt.savefig(root_output + name +'.png', bbox_inches="tight", dpi=300 )


    folder_kl = 'kl_loss/'
    make_folder(folder_kl)
    with open(folder_kl + name + '.npy', 'wb') as f:
        np.save(f, kl_loss)









def main():


    for initial in sys.argv[1:]:

        if initial == 'sin_gaussian_homo':
            example = 'sin'
            noise = 'gaussian_homo'
            test_initialGreen(initial, example, noise)

        elif initial == 'sin_gaussian_heter':
            example = 'sin'
            noise = 'gaussian_heter'
            test_initialGreen(initial, example, noise)

        elif initial == 'square_gaussian_homo':
            example = 'square'
            noise = 'gaussian_homo'
            test_initialGreen(initial, example, noise)

        elif initial == 'square_gaussian_heter':
            example = 'square'
            noise = 'gaussian_heter'
            test_initialGreen(initial, example, noise)

        elif initial == 'sin_laplace_homo':
            example = 'sin'
            noise = 'laplace_homo'
            test_initialGreen(initial, example, noise)

        elif initial == 'sin_laplace_heter':
            example = 'sin'
            noise = 'laplace_heter'
            test_initialGreen(initial, example, noise)

        elif initial == 'square_laplace_homo':
            example = 'square'
            noise = 'laplace_homo'
            test_initialGreen(initial, example, noise)

        elif initial == 'square_laplace_heter':
            example = 'square'
            noise = 'laplace_heter'
            test_initialGreen(initial, example, noise)

        else:
            print('{0} is not a test initial'.format(initial))
            continue


if __name__ == '__main__':
    main()






# # collects all saved results from experiments on given datasets
# #
# # USAGE:
# #   python collect_results.py dataset1 dataset2 ...
# root_orbit = 'orbit/'      # where to save orbits
# root_output = 'output/'   # where to save trained models
# root_plot = 'plotdata/'
# import sys
# import numpy as np
# import learning as ln
# import os
# from scipy import stats
# import matplotlib.pyplot as plt
# root_results = 'results/'  # folder where to save results


# def make_folder(folder):
#     """
#     Creates given folder (or path) if it doesn't exist.
#     """

#     if not os.path.exists(folder):
#         os.makedirs(folder)



# def collect_quad_gaussian_homo(data_name):
#     make_folder(root_plot)
#     make_folder(root_output)
#     with open(root_orbit + data_name+'.npy', 'rb') as f:
#         X_truth = np.load(f)
#         X_T = np.load(f)
#         X_label = np.load(f)
#     with open(root_orbit + data_name+'_nn.npy', 'rb') as f:
#         X_pred = np.load(f)

#     xdim = np.shape(X_pred)[1]
#     print(xdim)
#     kl_results = np.zeros((2,xdim))
#     mean_results = np.zeros((3,xdim))
#     mean_results[0,:] = np.mean(X_truth,axis=0) 
#     mean_results[1,:] = np.mean(X_label,axis=0)
#     mean_results[2,:] = np.mean(X_pred,axis=0)
#     std_results = np.zeros((3,xdim))
#     std_results[0,:] = np.std(X_truth,axis=0) 
#     std_results[1,:] = np.std(X_label,axis=0)
#     std_results[2,:] = np.std(X_pred,axis=0)
#     # marginal KL
#     for ii in range(xdim):
#     # for ii in range(1):
#         print(ii)
#         # for kl_div
#         xl,xr = np.min(X_truth[:,ii]),np.max(X_truth[:,ii])
#         x_kl = np.linspace(xl,xr, 1000)
#         kernel_truth = stats.gaussian_kde(X_truth[:,ii], bw_method=0.2)
#         kernel_label = stats.gaussian_kde(X_label[:,ii], bw_method=0.2)
#         kernel_pred = stats.gaussian_kde(X_pred[:,ii], bw_method=0.2)
#         kl_tl = np.sum( kernel_truth(x_kl)*(x_kl[1]-x_kl[0]) * np.log(  (kernel_truth(x_kl) + 1e-16) /  ( kernel_label(x_kl) + 1e-16)  ) )
#         kl_tp = np.sum( kernel_truth(x_kl)*(x_kl[1]-x_kl[0]) * np.log(  (kernel_truth(x_kl) + 1e-16) /  ( kernel_pred(x_kl) + 1e-16)  ) )
#         kl_results[0,ii] = kl_tl
#         kl_results[1,ii] = kl_tp


#         if ii == 0 or ii == 3:
#             # 1d marginal truth
#             plt.figure()
#             plt.cla()
#             plt.fill_between(x_kl,kernel_truth(x_kl),alpha=0.4)
#             plt.xticks(fontsize=14)
#             plt.tick_params(left = False, labelleft = False)
#             if ii == 3:
#                 plt.xlim([-0.5,1])
#                 kltruth_1d_3 = np.vstack((x_kl,kernel_truth(x_kl)))
#             elif ii == 0:
#                 kltruth_1d_0 = np.vstack((x_kl,kernel_truth(x_kl)))
#                 plt.xlim([-1,4])
#             plt.savefig(root_output + data_name + str(ii+1) + 'd_truth.png', bbox_inches="tight", dpi=300 )

#             # 1d marginal label
#             plt.figure()
#             plt.cla()
#             plt.fill_between(x_kl,kernel_label(x_kl),alpha=0.4)
#             if ii == 3:
#                 plt.xlim([-0.5,1])
#                 kllabel_1d_3 = np.vstack((x_kl,kernel_label(x_kl)))
#             elif ii == 0:
#                 kllabel_1d_0 = np.vstack((x_kl,kernel_label(x_kl)))
#                 plt.xlim([-1,4])
#             plt.xticks(fontsize=14)
#             plt.tick_params(left = False, labelleft = False)
#             plt.savefig(root_output + data_name + str(ii+1) + 'd_label.png', bbox_inches="tight", dpi=300 )

#             # 1d marginal pred
#             plt.figure()
#             plt.cla()
#             plt.fill_between(x_kl,kernel_pred(x_kl),alpha=0.4)
#             # plt.xlabel('d=' + str(ii+1),fontsize=23)
#             if ii == 3:
#                 plt.xlim([-0.5,1])
#                 klpred_1d_3 = np.vstack((x_kl,kernel_pred(x_kl)))
#             elif ii == 0:
#                 klpred_1d_0 = np.vstack((x_kl,kernel_pred(x_kl)))
#                 plt.xlim([-1,4])
#             plt.xticks(fontsize=14)
#             plt.tick_params(left = False, labelleft = False)
#             plt.savefig(root_output + data_name + str(ii+1) + 'd_pred.png', bbox_inches="tight", dpi=300 )


#     # 2d KDE
#     # truth: xi, p
#     xi = X_truth[:,1]
#     p = X_truth[:,4]
#     deltaX = (max(xi) - min(xi))/100
#     deltaY = (max(p) - min(p))/100
#     xmin = min(xi) - deltaX
#     xmax = max(xi) + deltaX
#     ymin = min(p) - deltaY
#     ymax = max(p) + deltaY
#     xx, yy = np.mgrid[xmin:xmax:50j, ymin:ymax:50j]
#     positions = np.vstack([xx.ravel(), yy.ravel()])
#     values = np.vstack([xi, p])
#     plt.figure()
#     plt.cla()
#     kernel2d_truth = stats.gaussian_kde(values)
#     f_truth = np.reshape(kernel2d_truth(positions).T, xx.shape)
#     plt.contourf(xx, yy, np.log10(f_truth+1e-10), cmap='coolwarm')
#     plt.xlim( -6, 5)
#     plt.ylim(-1,3)
#     plt.xticks(fontsize=14)
#     plt.yticks(fontsize=14)
#     plt.savefig(root_output + '2dtruth_' + data_name + '.png', bbox_inches="tight", dpi=300 )

#     # label: xi, p
#     xi = X_label[:,1]
#     p = X_label[:,4]
#     values = np.vstack([xi, p])
#     plt.figure()
#     plt.cla()
#     kernel2d_label = stats.gaussian_kde(values)
#     f_label = np.reshape(kernel2d_label(positions).T, xx.shape)
#     plt.contourf(xx, yy, np.log10(f_label+1e-10), cmap='coolwarm')
#     plt.xlim( -6, 5)
#     plt.ylim(-1,3)
#     plt.xticks(fontsize=14)
#     plt.yticks(fontsize=14)
#     plt.savefig(root_output + '2dlabel_' + data_name + '.png', bbox_inches="tight", dpi=300 )

#     # pred: xi, p
#     xi = X_pred[:,1]
#     p = X_pred[:,4]
#     values = np.vstack([xi, p])
#     plt.figure()
#     plt.cla()
#     kernel2d_pred = stats.gaussian_kde(values)
#     f_pred = np.reshape(kernel2d_pred(positions).T, xx.shape)
#     plt.contourf(xx, yy, np.log10(f_pred+1e-10), cmap='coolwarm')
#     plt.xlim( -6, 5)
#     plt.ylim(-1,3)
#     plt.xticks(fontsize=14)
#     plt.yticks(fontsize=14)
#     plt.savefig(root_output + '2dnn_' + data_name + '.png', bbox_inches="tight", dpi=300 )

#     # plot KL
#     plt.figure()
#     plt.cla()
#     plt.plot(np.arange(xdim, dtype=int)+1,kl_results[0,:], color="r")
#     plt.plot(np.arange(xdim, dtype=int)+1,kl_results[1,:], color="b")
#     plt.xlabel('dimension',fontsize=20)
#     plt.xlim(1, xdim)
#     plt.ylabel('KL divergence',fontsize=20)
#     plt.xticks(fontsize=12)
#     plt.yticks(fontsize=12)
#     plt.grid()        
#     plt.legend(['Labeled', 'Generated'],fontsize = 12, loc = 'upper left')
#     plt.savefig(root_output + 'KL_' + data_name + '.png', bbox_inches="tight", dpi=300 )

#     # plot mean
#     plt.figure()
#     plt.cla()
#     plt.plot(np.arange(xdim, dtype=int)+1,mean_results[0,:], color="r")
#     plt.plot(np.arange(xdim, dtype=int)+1,mean_results[1,:], color="b")
#     plt.plot(np.arange(xdim, dtype=int)+1,mean_results[2,:], color="k")

#     plt.xlabel('dimension',fontsize=20)
#     plt.xlim(1, xdim)
#     plt.ylim(-0.1,0.1)
#     plt.ylabel('mean',fontsize=20)
#     plt.xticks(fontsize=12)
#     plt.yticks(fontsize=12)
#     plt.grid()        
#     plt.legend(['Truth','Labeled', 'Generated'],fontsize = 12, loc = 'upper right')
#     plt.savefig(root_output + 'mean_' + data_name + '.png', bbox_inches="tight", dpi=300 )

#     # plot std
#     plt.figure()
#     plt.cla()
#     plt.plot(np.arange(xdim, dtype=int)+1,std_results[0,:], color="r")
#     plt.plot(np.arange(xdim, dtype=int)+1,std_results[1,:], color="b")
#     plt.plot(np.arange(xdim, dtype=int)+1,std_results[2,:], color="k")

#     plt.xlabel('dimension',fontsize=20)
#     plt.xlim(1, xdim)
#     plt.ylim(0.9,1.1)
#     plt.ylabel('std',fontsize=20)
#     plt.xticks(fontsize=12)
#     plt.yticks(fontsize=12)
#     plt.grid()        
#     plt.legend(['Truth','Labeled', 'Generated'],fontsize = 12, loc = 'upper right')
#     plt.savefig(root_output + 'std_' + data_name + '.png', bbox_inches="tight", dpi=300 )

#     np.savez(root_plot+data_name+'.npz',xdim=xdim, mean_results=mean_results, std_results=std_results, kl_results=kl_results, \
#              kltruth_1d_0=kltruth_1d_0, kltruth_1d_3=kltruth_1d_3,\
#              kllabel_1d_0=kllabel_1d_0, kllabel_1d_3=kllabel_1d_3,\
#              klpred_1d_0=klpred_1d_0, klpred_1d_3=klpred_1d_3,\
#              xx=xx, yy=yy, kltruth_2d=f_truth, kllabel_2d=f_label, klpred_2d=f_pred )





# def main():

#     for data in sys.argv[1:]:

#         if data == 'quad_gaussian_homo':
#             collect_quad_gaussian_homo(data)

#         else:
#             print('{0} is not a valid dataset'.format(data))
#             continue


# if __name__ == '__main__':
#     main()
