
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import pchip_interpolate

# set paths
root_result = 'kl_loss/'   # where to save trained models


# filename
plt.figure(figsize=(17,7))
ax = plt.subplot(2, 4, 1)

delete_idx = [5,15,25]
delete_idxsin = [6,5,15,25,24]

filename = 'sin_gaussian_homo'
loss_kl = np.load(root_result + filename + '.npy')
x0 = np.linspace(-0.9,1.9, num = 31)
ax = plt.subplot(2, 4, 1)
x0_smth = np.linspace(-0.9,1.9,1001)
loss_kl_smth =  pchip_interpolate(np.delete(x0,delete_idxsin), np.delete(loss_kl,delete_idxsin), x0_smth)
ax.plot(x0_smth,loss_kl_smth, linewidth=3)
ax.axvspan(-1, 0, alpha=0.5)
ax.axvspan(1, 2, alpha=0.5)
ax.set_xlim(-1,2)
ax.title.set_text('$f=\sin(x), \\varepsilon({x}) \sim \mathcal{N}(0,0.15)$')
plt.xlabel('$x$',fontsize = 12)
plt.ylabel('KL-divergence', fontsize = 12)
plt.xticks(fontsize = 12)
plt.yticks(fontsize = 12)


filename = 'sin_gaussian_heter'
loss_kl = np.load(root_result + filename + '.npy')
x0 = np.linspace(-0.9,1.9, num = 31)
ax = plt.subplot(2, 4, 2)
x0_smth = np.linspace(-0.9,1.9,1001)
loss_kl_smth =  pchip_interpolate(np.delete(x0,delete_idxsin), np.delete(loss_kl,delete_idxsin), x0_smth)
ax.plot(x0_smth,loss_kl_smth, linewidth=3)
ax.axvspan(-1, 0, alpha=0.5)
ax.axvspan(1, 2, alpha=0.5)
ax.set_xlim(-1,2)
ax.title.set_text('$f=\sin(x), \\varepsilon({x}) \sim \mathcal{N}(0,0.2 |f({ x})|)$')
plt.xlabel('$x$',fontsize = 12)
plt.ylabel('KL-divergence', fontsize = 12)
plt.xticks(fontsize = 12)
plt.yticks(fontsize = 12)


filename = 'square_gaussian_homo'
loss_kl = np.load(root_result + filename + '.npy')
x0 = np.linspace(-0.9,1.9, num = 31)
ax = plt.subplot(2, 4, 5)
x0_smth = np.linspace(-0.9,1.9,1001)
loss_kl_smth =  pchip_interpolate(np.delete(x0,delete_idx), np.delete(loss_kl,delete_idx), x0_smth)
ax.plot(x0_smth,loss_kl_smth, linewidth=3)
ax.axvspan(-1, 0, alpha=0.5)
ax.axvspan(1, 2, alpha=0.5)
ax.set_xlim(-1,2)
ax.title.set_text('$f=4(x-0.5)^2, \\varepsilon({x}) \sim \mathcal{N}(0,0.15)$')
plt.xlabel('$x$',fontsize = 12)
plt.ylabel('KL-divergence', fontsize = 12)
plt.xticks(fontsize = 12)
plt.yticks(fontsize = 12)


filename = 'square_gaussian_heter'
loss_kl = np.load(root_result + filename + '.npy')
x0 = np.linspace(-0.9,1.9, num = 31)
ax = plt.subplot(2, 4, 6)
x0_smth = np.linspace(-0.9,1.9,1001)
loss_kl_smth =  pchip_interpolate(np.delete(x0,delete_idx), np.delete(loss_kl,delete_idx), x0_smth)
ax.plot(x0_smth,loss_kl_smth, linewidth=3)
ax.axvspan(-1, 0, alpha=0.5)
ax.axvspan(1, 2, alpha=0.5)
ax.set_xlim(-1,2)
ax.title.set_text('$f=4(x-0.5)^2, \\varepsilon({x}) \sim \mathcal{N}(0,0.2 |f({ x})|)$')
plt.xlabel('$x$',fontsize = 12)
plt.ylabel('KL-divergence', fontsize = 12)
plt.xticks(fontsize = 12)
plt.yticks(fontsize = 12)


filename = 'sin_laplace_homo'
loss_kl = np.load(root_result + filename + '.npy')
x0 = np.linspace(-0.9,1.9, num = 31)
ax = plt.subplot(2, 4, 3)
x0_smth = np.linspace(-0.9,1.9,1001)
loss_kl_smth =  pchip_interpolate(np.delete(x0,delete_idxsin), np.delete(loss_kl,delete_idxsin), x0_smth)
ax.plot(x0_smth,loss_kl_smth, linewidth=3)
ax.axvspan(-1, 0, alpha=0.5)
ax.axvspan(1, 2, alpha=0.5)
ax.set_xlim(-1,2)
ax.title.set_text('$f=\sin(x), \\varepsilon({x}) \sim {\\rm Laplace}(0,0.1)$')
plt.xlabel('$x$',fontsize = 12)
plt.ylabel('KL-divergence', fontsize = 12)
plt.xticks(fontsize = 12)
plt.yticks(fontsize = 12)


filename = 'sin_laplace_heter'
loss_kl = np.load(root_result + filename + '.npy')
x0 = np.linspace(-0.9,1.9, num = 31)
ax = plt.subplot(2, 4, 4)
x0_smth = np.linspace(-0.9,1.9,1001)
loss_kl_smth =  pchip_interpolate(np.delete(x0,delete_idxsin), np.delete(loss_kl,delete_idxsin), x0_smth)
ax.plot(x0_smth,loss_kl_smth, linewidth=3)
ax.axvspan(-1, 0, alpha=0.5)
ax.axvspan(1, 2, alpha=0.5)
ax.set_xlim(-1,2)
ax.title.set_text('$f=\sin(x), \\varepsilon({x}) \sim {\\rm Laplace}(0,0.15|f({ x})|)$')
plt.xlabel('$x$',fontsize = 12)
plt.ylabel('KL-divergence', fontsize = 12)
plt.xticks(fontsize = 12)
plt.yticks(fontsize = 12)


filename = 'square_laplace_homo'
loss_kl = np.load(root_result + filename + '.npy')
x0 = np.linspace(-0.9,1.9, num = 31)
ax = plt.subplot(2, 4, 7)
x0_smth = np.linspace(-0.9,1.9,1001)
loss_kl_smth =  pchip_interpolate(np.delete(x0,delete_idx), np.delete(loss_kl,delete_idx), x0_smth)
ax.plot(x0_smth,loss_kl_smth, linewidth=3)
ax.axvspan(-1, 0, alpha=0.5)
ax.axvspan(1, 2, alpha=0.5)
ax.set_xlim(-1,2)
ax.title.set_text('$f=4(x-0.5)^2, \\varepsilon({x}) \sim {\\rm Laplace}(0,0.1)$')
plt.xlabel('$x$',fontsize = 12)
plt.ylabel('KL-divergence', fontsize = 12)
plt.xticks(fontsize = 12)
plt.yticks(fontsize = 12)


filename = 'square_laplace_heter'
loss_kl = np.load(root_result + filename + '.npy')
x0 = np.linspace(-0.9,1.9, num = 31)
ax = plt.subplot(2, 4, 8)
x0_smth = np.linspace(-0.9,1.9,1001)
loss_kl_smth =  pchip_interpolate(np.delete(x0,delete_idx), np.delete(loss_kl,delete_idx), x0_smth)
ax.plot(x0_smth,loss_kl_smth, linewidth=3)
ax.axvspan(-1, 0, alpha=0.5)
ax.axvspan(1, 2, alpha=0.5)
ax.set_xlim(-1,2)
ax.title.set_text('$f=4(x-0.5)^2, \\varepsilon({x}) \sim {\\rm Laplace}(0,0.15|f({ x})|)$')
plt.xlabel('$x$',fontsize = 12)
plt.ylabel('KL-divergence', fontsize = 12)
plt.xticks(fontsize = 12)
plt.yticks(fontsize = 12)

plt.subplots_adjust(hspace=0.35)
plt.subplots_adjust(wspace=0.3)
plt.show()
plt.savefig('kl_global.pdf',bbox_inches="tight")





#  # plots
# plt.figure(figsize=(10, 5))
# ax = plt.subplot(1, 2, 1)
# ax2 = plt.subplot(1, 2, 2)
# min_entr = np.zeros(12)
# idx = 0
# for ii in C_rev:
    
#     filename = root_result + str(example) + '/' + str(ii) + '/train_lambda' +  str(ii) + '.npy'
#     with open(filename, 'rb') as f:
#         valida_loss = np.load(f)
    
#     # row_valid = 

#     epoch = valida_loss[:,0]
#     total_loss = valida_loss[:,1]
#     cross_entr = valida_loss[:,2]

   
#     ax.plot(epoch, cross_entr)
#     min_entr[idx] = np.ndarray.min(cross_entr)

#     idx = idx + 1

# ax2.semilogx(C_rev, min_entr)
# plt.grid(True, which="both")
# plt.show()
# plt.savefig('cross_entr.png', dpi=150, bbox_inches='tight')


exit()
