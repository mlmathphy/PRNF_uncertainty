import sys
import numpy as np
import os
import torch
import matplotlib.pyplot as plt
from numpy import matlib
import torch.nn as nn
import scipy.integrate as integrate
from scipy.stats import norm
from scipy.stats import laplace

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device',device)


# set paths
root_output = 'output/'   # where to save trained models
root_results = 'eval_result/'  # folder where to save results
root_data = 'data/initial/'       # where the datasets are

data = None
data_name = None


def load_test_data(name):
    """
    Loads the dataset. Has to be called before anything else.
    :param name: string, the dataset's name
    """
    # normalization
    static_name = 'data/' + name + '_mean_std.npy'
    with open(static_name, 'rb') as f:
        mu = np.load(f)
        s = np.load(f)


    assert isinstance(name, str), 'Name must be a string'
    global data,  data_name
    num_sample = 20000
    if data_name == name:
        return

    elif name == 'sin_gaussian_homo':
        # x0 = np.linspace(0.05,0.95, num = 37)
        x0 = np.array([-0.8,0.2,0.8,1.8])
        
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)


    elif name == 'sin_gaussian_heter':
        x0 = np.array([-0.8,0.2,0.8,1.8])
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)


    elif name == 'square_gaussian_homo':
        x0 = np.array([-0.8,0.2,0.8,1.8])
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    elif name == 'square_gaussian_heter':
        x0 = np.array([-0.8,0.2,0.8,1.8])
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    elif name == 'sin_laplace_homo':
        x0 = np.array([-0.8,0.2,0.8,1.8])
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    elif name == 'sin_laplace_heter':
        x0 = np.array([-0.8,0.2,0.8,1.8])
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    elif name == 'square_laplace_homo':
        x0 = np.array([-0.8,0.2,0.8,1.8])
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    elif name == 'square_laplace_heter':
        x0 = np.array([-0.8,0.2,0.8,1.8])
        x0 = (x0 - mu[0]) / s[0]        ## normalize
        x = matlib.repmat(x0, num_sample, 1)

    else:
        raise ValueError('Unknown dataset')
    
    data = x
    data_name = name



def is_data_loaded():
    """
    Checks whether a dataset has been loaded.
    :return: boolean
    """
    return data_name is not None



def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)




def load_checkpoint(filepath, dim):
    """
    Load checkpoint
    """
    checkpoint = torch.load(filepath)
    model = NF_Net(dim).to(device)
    model.load_state_dict(checkpoint['state_dict'])
    return model


def load_model(dim, model_name):
    """
    Load model
    """

    assert is_data_loaded(), 'Dataset hasn\'t been loaded'

    savedir = root_output
    filename = model_name

    print(savedir + filename + '.pt')
    device = torch.device("cuda")
    model = load_checkpoint(savedir + filename + '.pt', dim)
    model.to(device)
    model.eval()
    return model




class NF_Net(nn.Module):

    def __init__(self, dim):
        super(NF_Net, self).__init__()

        self.dim = dim
        self.hid_size = 256

        self.input = nn.Linear(2 * self.dim, self.hid_size)
        self.fc1= nn.Linear(self.hid_size,self.hid_size)
        self.output = nn.Linear(self.hid_size,self.dim)

        self.inv_input = nn.Linear(2 * self.dim, self.hid_size)
        self.inv_fc1= nn.Linear(self.hid_size,self.hid_size)
        self.inv_output = nn.Linear(self.hid_size,self.dim)


    def backward(self, x, dim):

        y0 = x[:, 0: dim]
        x = torch.tanh(self.inv_input(x))
        x = torch.tanh(self.inv_fc1(x))
        x = self.inv_output(x)
        x = torch.cat((y0, x), 1)
        return x



def test_initialGreen(name):

    savedir = 'evalresult/' + name + '/'
    make_folder(savedir)

    print('initial distribution is {0}...'.format(name))
    load_test_data(name)
    dim = 1
    print('dimensionality is ', dim)
    try:
        NF = load_model(dim, name)

    except IOError:
        return 'N/A'

    static_name = 'data/' + name + '_mean_std.npy'
    with open(static_name, 'rb') as f:
        mu = np.load(f)
        std = np.load(f)

    ## test:
    N_test, N_point = data.shape ## note all data has been normalized
    z_sample0 = np.random.randn(N_test,dim)


    fig, axs = plt.subplots(nrows=1, ncols=N_point,figsize=(17,3.5),layout='constrained')
    # fig.figure(figsize=(17,4))
    # plt.locator_params(nbins=4)

    for i in range(N_point):
        print(i)
        y0 = data[:,i]
        y0z_sample0 = np.column_stack( (y0,z_sample0) )

        y0z_sample = torch.as_tensor(y0z_sample0,dtype=torch.float,device = device)
        y0_y = NF.backward(y0z_sample, dim)
        y = y0_y[:,dim:2 * dim]
        y_pred = y.to('cpu').detach().numpy()   # approximation
        y_pred = std[1] * y_pred + mu[1]


        leg_hist = ('PR-NF' )
        leg_str = ('exact')

        axs[i].hist(y_pred, density='true', bins=30, label=leg_hist)

        x0 = np.array([-0.8,0.2,0.8,1.8])
        if i == 0 or i == 3:
            axs[i].title.set_text('outside point $x=$' + str(x0[i]))
        else:
            axs[i].title.set_text('inside point $x=$' + str(x0[i]))
        axs[i].title.set_size(14)
        if name == "sin_gaussian_homo":
            x_hist = np.linspace(-1.5,1.5,1001) ## 
            axs[i].plot(x_hist, norm.pdf(x_hist, np.sin(2*np.pi*(std[0]*y0[0]+ mu[0])), 0.15), label=leg_str, linewidth=3)
            # plt.xlim(right=1.5)  # adjust the right leaving left unchanged
            # plt.xlim(left=-1.5)  # adjust the left leaving right unchanged
            fig.suptitle('$f=\sin(x), \\varepsilon({x}) \sim \mathcal{N}(0,0.15)$',fontsize=15)
 

        elif name == "sin_gaussian_heter":
            x_hist = np.linspace(-1.5,1.5,1001) ## 
            axs[i].plot(x_hist, norm.pdf(x_hist, np.sin(2*np.pi*(std[0]*y0[0]+ mu[0])), 0.2 * np.abs(np.sin(2*np.pi*(std[0]*y0[0]+ mu[0])))), label=leg_str, linewidth=3)
            fig.suptitle('$f=\sin(x), \\varepsilon({x}) \sim \mathcal{N}(0,0.2 |f({ x})|)$',fontsize=15)
 

        elif name == "square_gaussian_homo":
            if i == 0 or i == 3:
                x_hist = np.linspace(-0.0,7.5,1001) ## 
            else:
                x_hist = np.linspace(-1.0,1.5,1001) ## 
            axs[i].plot(x_hist, norm.pdf(x_hist, 4.0*(std[0]*y0[0]+ mu[0]-0.5)**2, 0.15), label=leg_str, linewidth=3)
            fig.suptitle('$f=4(x-0.5)^2, \\varepsilon({x}) \sim \mathcal{N}(0,0.15)$',fontsize=15)
 

        elif name == "square_gaussian_heter":
            if i == 0 or i == 3:
                x_hist = np.linspace(-0.0,7.5,1001) ## 
            else:
                x_hist = np.linspace(-1.0,1.5,1001) ## 
            axs[i].plot(x_hist, norm.pdf(x_hist, 4.0*(std[0]*y0[0]+ mu[0]-0.5)**2, 0.2 * np.abs(4.0*(std[0]*y0[0]+ mu[0]-0.5)**2)), label=leg_str, linewidth=3)
            fig.suptitle('$f=4(x-0.5)^2, \\varepsilon({x}) \sim \mathcal{N}(0,0.2 |f({ x})|)$',fontsize=15)
 

        elif name == "sin_laplace_homo":
            x_hist = np.linspace(-1.5,1.5,1001) ## 
            axs[i].plot(x_hist, laplace.pdf(x_hist, np.sin(2*np.pi*(std[0]*y0[0]+ mu[0])), 0.1), label=leg_str, linewidth=3)
            fig.suptitle('$f=\sin(x), \\varepsilon({x}) \sim {\\rm Laplace}(0,0.1)$',fontsize=15)
 

        elif name == "sin_laplace_heter":
            x_hist = np.linspace(-1.5,1.5,1001) ## 
            axs[i].plot(x_hist, laplace.pdf(x_hist, np.sin(2*np.pi*(std[0]*y0[0]+ mu[0])), 0.15 * np.abs(np.sin(2*np.pi*(std[0]*y0[0]+ mu[0])))), label=leg_str, linewidth=3)
            fig.suptitle('$f=\sin(x), \\varepsilon({x}) \sim {\\rm Laplace}(0,0.15|f({ x})|)$',fontsize=15)
 

        elif name == "square_laplace_homo":
            if i == 0 or i == 3:
                x_hist = np.linspace(-0.0,7.5,1001) ## 
            else:
                x_hist = np.linspace(-1.0,1.5,1001) ## 
            axs[i].plot(x_hist, laplace.pdf(x_hist, 4.0*(std[0]*y0[0]+ mu[0]-0.5)**2, 0.1), label=leg_str, linewidth=3)
            fig.suptitle('$f=4(x-0.5)^2, \\varepsilon({x}) \sim {\\rm Laplace}(0,0.1)$',fontsize=15)
   

        elif name == "square_laplace_heter":
            if i == 0 or i == 3:
                x_hist = np.linspace(0.0,7.5,1001) ## 
            else:
                x_hist = np.linspace(-1.0,1.5,1001) ## 
            axs[i].plot(x_hist, laplace.pdf(x_hist, 4.0*(std[0]*y0[0]+ mu[0]-0.5)**2, 0.15 * np.abs(4.0*(std[0]*y0[0]+ mu[0]-0.5)**2)), label=leg_str, linewidth=3)
            fig.suptitle('$f=4(x-0.5)^2, \\varepsilon({x}) \sim {\\rm Laplace}(0,0.15|f({ x})|)$',fontsize=15)
 

        axs[i].legend(loc='best',fontsize=14)
        axs[i].set_xlabel('$y$',fontsize=14)
        axs[i].set_ylabel('$p(y|x)$',fontsize=14)
        axs[i].tick_params(axis='both', which='major', labelsize=14)


    # plt.grid()  
    # plt.subplots_adjust(hspace=0.35)
    # plt.subplots_adjust(wspace=0.3)      
    plt.savefig(savedir + 'noise_' + name + '.pdf', bbox_inches="tight")






def main():


    for initial in sys.argv[1:]:

        if initial == 'sin_gaussian_homo':
            test_initialGreen(initial)

        elif initial == 'sin_gaussian_heter':
            test_initialGreen(initial)

        elif initial == 'square_gaussian_homo':
            test_initialGreen(initial)

        elif initial == 'square_gaussian_heter':
            test_initialGreen(initial)

        elif initial == 'sin_laplace_homo':
            test_initialGreen(initial)

        elif initial == 'sin_laplace_heter':
            test_initialGreen(initial)

        elif initial == 'square_laplace_homo':
            test_initialGreen(initial)

        elif initial == 'square_laplace_heter':
            test_initialGreen(initial)

        else:
            print('{0} is not a test initial'.format(initial))
            continue


if __name__ == '__main__':
    main()
