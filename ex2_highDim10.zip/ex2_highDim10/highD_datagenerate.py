import numpy as np
# from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from scipy.stats import norm
import os
import scipy.io
from scipy.stats import multivariate_normal
from sklearn.datasets import make_spd_matrix
seed = 12345
np.random.seed(seed)

root_data = 'data/'       # where the datasets are

# print(np.__version__)
# print(scipy.__version__)


def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)



def deterministic(x_sample, type, coeff):
    
    if type == 'linear':
        y_sample = np.matmul(x_sample,coeff) # Ns*dx X dx*dy 

    else:
        print('wrong deterministic function')

    return y_sample



def noise(Ns,dy,type):

    if type == 'gaussian_one':
        noise = np.random.normal(0, 0.1, size=(Ns,dy))

    elif type == 'gaussian_two':
        noise1 = np.random.normal(-0.1, 0.1, size=(int(Ns/2),dy))
        noise2 = np.random.normal(0.1, 0.1, size=(int(Ns/2),dy))
        noise = np.vstack((noise1,noise2))

    elif type == 'gaussian_cov':
        mean = np.zeros(dy)
        # mean = np.zeros(dim)
        cov_matrix = make_spd_matrix(n_dim=dy, random_state=None)
        print(mean)
        print(cov_matrix)
        ## Saving validation results vs epoch to .npy file  
        filename='cov_matrix'
        with open(savedir + filename + '.npy', 'wb') as f:
            np.save(f, cov_matrix)

        rv = multivariate_normal(mean, cov_matrix)
        noise = rv.rvs(size=Ns, random_state=None)


    return noise


def F_forward(Ns, sample_type, dx, dy,coeff):
    
    if sample_type == 'one':
        x_sample = np.random.uniform(low=0.0, high=1.0, size=(Ns,dx))
        y_sample = deterministic(x_sample,'linear',coeff)    # y =f(x)
        epi = noise(Ns,dy,'gaussian_one')
        y_sample = y_sample + epi
        print('gaussian_one')

    elif sample_type == 'two':

        x_sample = np.random.uniform(low=0.0, high=1.0, size=(Ns,dx))
        y_sample = deterministic(x_sample,'linear',coeff)    # y =f(x)
        epi = noise(Ns,dy,'gaussian_two')
        y_sample = y_sample + epi
        print('gaussian_two')

    elif sample_type == 'cov':

        x_sample = np.random.uniform(low=0.0, high=1.0, size=(Ns,dx))
        y_sample = deterministic(x_sample,'linear',coeff)    # y =f(x)
        epi = noise(Ns,dy,'gaussian_cov')
        y_sample = y_sample + epi
        print('gaussian_cov')
    else:
        print('wrong samples')


    return x_sample, y_sample





# ------------------------------------------------
#                The main routine
# ------------------------------------------------
# savedir = root_data + 'analyforward_gaussian_one/'
savedir = root_data + 'analyforward_gaussian_two/'
# savedir = root_data + 'analyforward_gaussian_cov/'
make_folder(savedir)



######-----analytical dataset-----######
# The dimension of input parameterspace
d_x = 20    # dimensionality of input x
d_y = 10    # dimensionality of output y


# training & validation dataset 
NV = 30000
N_train = 2*NV      # number of training samples
N_test = NV         # number of test samples

coeff = np.random.uniform(low=0.0, high=1.0, size=(d_x,d_y)) 
print('coefficient shape', coeff.shape)
x_train, y_train = F_forward(N_train,'two', d_x, d_y,coeff)


## Saving validation results vs epoch to .npy file  
filename='train_data'
with open(savedir + filename + '.npy', 'wb') as f:
    np.save(f, x_train)
    np.save(f, y_train)
    np.save(f, coeff)




exit()

























