import sys
import numpy as np
import os
import torch
import matplotlib.pyplot as plt
from numpy import matlib
import torch.nn as nn
import scipy.integrate as integrate
from scipy.stats import norm
from scipy.stats import laplace
from sklearn.metrics import mean_squared_error
from scipy import stats
from scipy.stats import multivariate_normal


device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device',device)


# set paths
root_output = 'output/'   # where to save trained models
root_results = 'eval_result/'  # folder where to save results
root_data = 'data/'       # where the datasets are

data = None
data_name = None


def load_test_data(name):
    """
    Loads the dataset. Has to be called before anything else.
    :param name: string, the dataset's name
    """
    # normalization
    static_name = 'data/' + name + '/mean_std.npy'
    with open(static_name, 'rb') as f:
        mu = np.load(f)
        s = np.load(f)


    assert isinstance(name, str), 'Name must be a string'
    global data_single, data,  data_name

    if data_name == name:
        return

    elif name == 'analyforward_gaussian_one':

        test_num = 100
        dim=20
        x0 = np.random.uniform(low=0.0, high=1.0, size=(test_num,dim))
        x = (x0 - mu) / s       ## normalize
    
    elif name == 'analyforward_gaussian_two':

        test_num = 100
        dim=20
        x0 = np.random.uniform(low=0.0, high=1.0, size=(test_num,dim))
        x = (x0 - mu) / s       ## normalize    


    elif name == 'analyforward_gaussian_cov':

        test_num = 100
        dim=20
        x0 = np.random.uniform(low=0.0, high=1.0, size=(test_num,dim))
        x = (x0 - mu) / s       ## normalize    


    else:
        raise ValueError('Unknown dataset')
    
    data_single = x0
    data = x
    data_name = name



def is_data_loaded():
    """
    Checks whether a dataset has been loaded.
    :return: boolean
    """
    return data_name is not None




def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)




def load_checkpoint(filepath, dim_x,dim_y):
    """
    Load checkpoint
    """
    checkpoint = torch.load(filepath)
    model = NF_Net(dim_x,dim_y).to(device)
    model.load_state_dict(checkpoint['state_dict'])
    return model


def load_model(dim_x,dim_y, model_name):
    """
    Load model
    """

    assert is_data_loaded(), 'Dataset hasn\'t been loaded'

    savedir = root_output
    filename = model_name

    print(savedir + filename + '.pt')
    device = torch.device("cuda")
    model = load_checkpoint(savedir + filename + '.pt', dim_x,dim_y)
    model.to(device)
    model.eval()
    return model




class NF_Net(nn.Module):

    def __init__(self, dim_x, dim_y):
        super(NF_Net, self).__init__()

        self.dim = dim_x + dim_y
        self.x_dim = dim_x
        self.y_dim = dim_y
        self.hid_size = 512

        self.input = nn.Linear(self.dim, self.hid_size)
        self.fc1= nn.Linear(self.hid_size,self.hid_size)
        self.output = nn.Linear(self.hid_size,self.y_dim)

        self.inv_input = nn.Linear(self.dim, self.hid_size)
        self.inv_fc1= nn.Linear(self.hid_size,self.hid_size)
        self.inv_output = nn.Linear(self.hid_size,self.y_dim)


    def backward(self, x):

        y0 = x[:, 0: self.x_dim]
        x = torch.tanh(self.inv_input(x))
        x = torch.tanh(self.inv_fc1(x))
        x = self.inv_output(x)
        x = torch.cat((y0, x), 1)
        return x



def test_initialGreenone(name):
    num_sample = 20000
    savedir = 'evalresult/' + name + '/'
    make_folder(savedir)

    dim_x=20
    dim_y=10
    dim = dim_x + dim_y
    print('initial distribution is {0}...'.format(name))
    load_test_data(name)

    # print('dimensionality is ', dim_x)
    try:
        NF = load_model(dim_x,dim_y, name)

    except IOError:
        return 'N/A'

    static_name = 'data/' + name + '/mean_std.npy'
    with open(static_name, 'rb') as f:
        mu_x = np.load(f)
        std_x = np.load(f)
        mu_y = np.load(f)
        std_y = np.load(f)

    ## test:
    N_point,_ = data.shape ## note all data has been normalized
    z_sample0 = np.random.randn(num_sample,dim_y)

    fx_pred = np.zeros((N_point,dim_y))
    std_pred = np.zeros((N_point,dim_y))

    mean_error = np.zeros(N_point)
    std_error = np.zeros(N_point)

    train_name = root_data + 'analyforward_gaussian_one/train_data.npy'
    with open(train_name, 'rb') as f:
        x_train = np.load(f)
        y_train = np.load(f)
        coeff = np.load(f)
    fx_exact = np.matmul(data_single,coeff) # Ns*dx X dx*dy
    std_exact = 0.1


    noise_exact = np.random.normal(0, 0.1, size=(num_sample,dim_y))
    kl_results = np.zeros(5)
    kl_results_temp = np.zeros((5,dim_y))

    for i in range(N_point):
        y0 = matlib.repmat(data[i,:], num_sample, 1)

        y0z_sample0 = np.column_stack( (y0,z_sample0) )

        y0z_sample = torch.as_tensor(y0z_sample0,dtype=torch.float,device = device)
        y0_y = NF.backward(y0z_sample)
        y = y0_y[:,dim_x:dim]
        y_pred = y.to('cpu').detach().numpy()   # approximation
        y_pred = std_y * y_pred + mu_y

        fx_pred[i] = np.mean(y_pred,axis = 0)
        std_pred[i] = np.std(y_pred,axis = 0)

        mean_error[i] = np.linalg.norm(fx_pred[i]-fx_exact[i],ord=2)/np.linalg.norm(fx_exact[i],ord=2)
        # std_error[i] = np.linalg.norm(std_pred[i]-std_exact*np.ones_like(std_pred[i]),ord=2)/np.linalg.norm(std_exact*np.ones_like(std_pred[i]),ord=2)

        # mean_error[i] = np.linalg.norm(fx_pred[i]-fx_exact[i],ord=2)/np.sqrt(dim_y)
        std_error[i] = np.linalg.norm(std_pred[i]-std_exact*np.ones_like(std_pred[i]),ord=2)/np.sqrt(dim_y)


        if i <5 :
            for ii in range(dim_y):
                
                # xl,xr = np.min(noise_exact[:,ii]),np.max(noise_exact[:,ii])
                xl,xr = -0.3,0.3
                x_kl = np.linspace(xl,xr, 1000)
                kernel_truth = stats.gaussian_kde(noise_exact[:,ii], bw_method=0.2)

                kernel_pred = stats.gaussian_kde(y_pred[:,ii]-fx_pred[i,ii], bw_method=0.2)
                if i == 0:
                    plt.figure()
                    plt.cla()
                    plt.fill_between(x_kl,kernel_truth(x_kl),alpha=0.4)
                    plt.fill_between(x_kl,kernel_pred(x_kl),alpha=0.4)
                    plt.savefig('two_kl.png', bbox_inches="tight", dpi=300 )
                    
                
                kl_tp = np.sum( kernel_truth(x_kl)*(x_kl[1]-x_kl[0]) * np.log(  (kernel_truth(x_kl) + 1e-16) /  ( kernel_pred(x_kl) + 1e-16)  ) )

                kl_results_temp[i,ii] = kl_tp
                kl_results[i] = np.linalg.norm(kl_results_temp[i,:],ord=2)/np.sqrt(float(dim_y))


    print(np.mean(std_error))
    print(np.mean(mean_error))
    print(np.mean(kl_results))




def test_initialGreentwo(name):
    num_sample = 20000
    savedir = 'evalresult/' + name + '/'
    make_folder(savedir)

    dim_x=20
    dim_y=10
    dim = dim_x + dim_y
    print('initial distribution is {0}...'.format(name))
    load_test_data(name)

    # print('dimensionality is ', dim_x)
    try:
        NF = load_model(dim_x,dim_y, name)

    except IOError:
        return 'N/A'

    static_name = 'data/' + name + '/mean_std.npy'
    with open(static_name, 'rb') as f:
        mu_x = np.load(f)
        std_x = np.load(f)
        mu_y = np.load(f)
        std_y = np.load(f)

    ## test:
    N_point,_ = data.shape ## note all data has been normalized
    z_sample0 = np.random.randn(num_sample,dim_y)

    fx_pred = np.zeros((N_point,dim_y))
    std_pred = np.zeros((N_point,dim_y))

    mean_error = np.zeros(N_point)
    std_error = np.zeros(N_point)

    train_name = root_data + 'analyforward_gaussian_one/train_data.npy'
    with open(train_name, 'rb') as f:
        x_train = np.load(f)
        y_train = np.load(f)
        coeff = np.load(f)
    fx_exact = np.matmul(data_single,coeff) # Ns*dx X dx*dy
    std_exact = 0.1414


    noise1 = np.random.normal(-0.1, 0.1, size=(int(num_sample/2),dim_y))
    noise2 = np.random.normal(0.1, 0.1, size=(int(num_sample/2),dim_y))
    noise_exact = np.vstack((noise1,noise2))

    kl_results = np.zeros(5)
    kl_results_temp = np.zeros((5,dim_y))

    for i in range(N_point):
        y0 = matlib.repmat(data[i,:], num_sample, 1)

        y0z_sample0 = np.column_stack( (y0,z_sample0) )

        y0z_sample = torch.as_tensor(y0z_sample0,dtype=torch.float,device = device)
        y0_y = NF.backward(y0z_sample)
        y = y0_y[:,dim_x:dim]
        y_pred = y.to('cpu').detach().numpy()   # approximation
        y_pred = std_y * y_pred + mu_y

        fx_pred[i] = np.mean(y_pred,axis = 0)
        std_pred[i] = np.std(y_pred,axis = 0)

        mean_error[i] = np.linalg.norm(fx_pred[i]-fx_exact[i],ord=2)/np.linalg.norm(fx_exact[i],ord=2)
        # std_error[i] = np.linalg.norm(std_pred[i]-std_exact*np.ones_like(std_pred[i]),ord=2)/np.linalg.norm(std_exact*np.ones_like(std_pred[i]),ord=2)

        # mean_error[i] = np.linalg.norm(fx_pred[i]-fx_exact[i],ord=2)/np.sqrt(dim_y)
        std_error[i] = np.linalg.norm(std_pred[i]-std_exact*np.ones_like(std_pred[i]),ord=2)/np.sqrt(dim_y)


        if i <5 :
            for ii in range(dim_y):
                
                # xl,xr = np.min(noise_exact[:,ii]),np.max(noise_exact[:,ii])
                xl,xr = -0.4,0.4
                x_kl = np.linspace(xl,xr, 1000)
                kernel_truth = stats.gaussian_kde(noise_exact[:,ii], bw_method=0.2)

                kernel_pred = stats.gaussian_kde(y_pred[:,ii]-fx_pred[i,ii], bw_method=0.2)
                if i == 0:
                    plt.figure()
                    plt.cla()
                    plt.fill_between(x_kl,kernel_truth(x_kl),alpha=0.4)
                    plt.fill_between(x_kl,kernel_pred(x_kl),alpha=0.4)
                    plt.savefig('two_kl.png', bbox_inches="tight", dpi=300 )
                    
                
                kl_tp = np.sum( kernel_truth(x_kl)*(x_kl[1]-x_kl[0]) * np.log(  (kernel_truth(x_kl) + 1e-16) /  ( kernel_pred(x_kl) + 1e-16)  ) )

                kl_results_temp[i,ii] = kl_tp
                kl_results[i] = np.linalg.norm(kl_results_temp[i,:],ord=2)/np.sqrt(float(dim_y))


    print(np.mean(std_error))
    print(np.mean(mean_error))
    print(np.mean(kl_results))



def test_initialGreencov(name):
    num_sample = 20000
    savedir = 'evalresult/' + name + '/'
    make_folder(savedir)

    dim_x=20
    dim_y=10
    dim = dim_x + dim_y
    print('initial distribution is {0}...'.format(name))
    load_test_data(name)

    # print('dimensionality is ', dim_x)
    try:
        NF = load_model(dim_x,dim_y, name)

    except IOError:
        return 'N/A'

    static_name = 'data/' + name + '/mean_std.npy'
    with open(static_name, 'rb') as f:
        mu_x = np.load(f)
        std_x = np.load(f)
        mu_y = np.load(f)
        std_y = np.load(f)

    ## test:
    N_point,_ = data.shape ## note all data has been normalized
    z_sample0 = np.random.randn(num_sample,dim_y)

    fx_pred = np.zeros((N_point,dim_y))
    mean_error = np.zeros(N_point)
    cov_pred = np.zeros((N_point,dim_y,dim_y))
    cov_error = np.zeros(N_point)

    cov_name = root_data + 'analyforward_gaussian_cov/cov_matrix.npy'
    with open(cov_name, 'rb') as f:
        cov_exact = np.load(f)

    train_name = root_data + 'analyforward_gaussian_cov/train_data.npy'
    with open(train_name, 'rb') as f:
        x_train = np.load(f)
        y_train = np.load(f)
        coeff = np.load(f)
    fx_exact = np.matmul(data_single,coeff) # Ns*dx X dx*dy



    mean = np.zeros(dim_y)
    rv = multivariate_normal(mean, cov_exact)
    noise_exact = rv.rvs(size=num_sample, random_state=None)

    kl_results = np.zeros(5)
    kl_results_temp = np.zeros((5,dim_y))

    for i in range(N_point):
        y0 = matlib.repmat(data[i,:], num_sample, 1)

        y0z_sample0 = np.column_stack( (y0,z_sample0) )

        y0z_sample = torch.as_tensor(y0z_sample0,dtype=torch.float,device = device)
        y0_y = NF.backward(y0z_sample)
        y = y0_y[:,dim_x:dim]
        y_pred = y.to('cpu').detach().numpy()   # approximation
        y_pred = std_y * y_pred + mu_y

        fx_pred[i] = np.mean(y_pred,axis = 0)
        # print(np.cov(y_pred.T).shape)
        cov_pred[i,:,:] = np.cov(y_pred.T)
        # print(cov_pred[i,:,:])
        # print(cov_exact)
        # exit()
        # cov_error[i] = np.linalg.norm(cov_pred[i,:,:] - cov_exact,ord='fro')/np.linalg.norm(cov_exact,ord='fro')
        cov_error[i] = np.linalg.norm(cov_pred[i,:,:] - cov_exact,ord='fro')/float(dim_y)
        mean_error[i] = np.linalg.norm(fx_pred[i]-fx_exact[i],ord=2)/np.linalg.norm(fx_exact[i],ord=2)


        if i <5 :
            for ii in range(dim_y):
                
                xl,xr = np.min(noise_exact[:,ii]),np.max(noise_exact[:,ii])
                x_kl = np.linspace(xl,xr, 1000)
                kernel_truth = stats.gaussian_kde(noise_exact[:,ii], bw_method=0.2)

                kernel_pred = stats.gaussian_kde(y_pred[:,ii]-fx_pred[i,ii], bw_method=0.2)
                if i == 0:
                    plt.figure()
                    plt.cla()
                    plt.fill_between(x_kl,kernel_truth(x_kl),alpha=0.4)
                    plt.fill_between(x_kl,kernel_pred(x_kl),alpha=0.4)
                    plt.savefig('two_kl.png', bbox_inches="tight", dpi=300 )
                    
                kl_tp = np.sum( kernel_truth(x_kl)*(x_kl[1]-x_kl[0]) * np.log(  (kernel_truth(x_kl) + 1e-16) /  ( kernel_pred(x_kl) + 1e-16)  ) )

                kl_results_temp[i,ii] = kl_tp
                kl_results[i] = np.linalg.norm(kl_results_temp[i,:],ord=2)/np.sqrt(float(dim_y))
    print(np.mean(cov_error))
    print(np.mean(mean_error))
    print(np.mean(kl_results))














def main():


    for initial in sys.argv[1:]:

        if initial == 'analyforward_gaussian_one':
            test_initialGreenone(initial)

        elif initial == 'analyforward_gaussian_two':
            test_initialGreentwo(initial)

        elif initial == 'analyforward_gaussian_cov':
            test_initialGreencov(initial)
        else:
            print('{0} is not a test initial'.format(initial))
            continue


if __name__ == '__main__':
    main()
