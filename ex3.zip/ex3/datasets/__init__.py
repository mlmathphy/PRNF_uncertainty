root = 'data/'
from .earth_inv import *