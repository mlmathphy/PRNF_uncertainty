import numpy as np
import os
import matplotlib.pyplot as plt



seed = 1234
np.random.seed(seed)

root_data = 'data/'       # where the datasets are

def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)


######################################################
##--- define the parameter
######################################################
savedir = root_data
make_folder(savedir)


xdata = np.load('pre_observation.npy')
ydata = np.load('pre_latent.npy')


ydata_ori = ydata

# print(xdata.shape)
# print(ydata.shape)

x_rm = np.where(np.abs(np.std(xdata, axis=0)-0.)<1e-5)
y_rm = np.where(np.abs(np.std(ydata, axis=0)-0.)<1e-5)
xdata = np.delete(xdata,x_rm,axis=1)
ydata = np.delete(ydata,y_rm,axis=1)
# print(x_rm)
# print(y_rm)
# print(xdata.shape)
# print(ydata.shape)
# exit()


# exit()






x_train = xdata
y_train = ydata


plt.figure(figsize=(12, 15))
plt.subplots_adjust(hspace=0.5)

for jj in range(40):
    ax = plt.subplot(8,5,jj+1)
    ax.hist(x_train[:,jj])
plt.savefig('trainobs.png', bbox_inches="tight", dpi=300)

plt.figure(figsize=(20, 12))
plt.subplots_adjust(hspace=0.5)
for ii in range(15):
    ax = plt.subplot(3,5,ii+1)
    ax.hist(y_train[:,ii])
plt.savefig('trainlat.png', bbox_inches="tight", dpi=300)

plt.figure(figsize=(20, 15))
plt.subplots_adjust(hspace=0.5)
for ii in range(20):
    ax = plt.subplot(4,5,ii+1)
    ax.hist(ydata_ori[:,ii])
plt.savefig('trainlatori.png', bbox_inches="tight", dpi=300)

exit()
print(ydata[:,2])

filename='train_data'
with open(savedir + filename + '.npy', 'wb') as f:
    np.save(f, x_train)
    np.save(f, y_train)

