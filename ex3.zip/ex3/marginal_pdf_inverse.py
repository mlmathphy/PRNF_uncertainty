import sys
import numpy as np
import os
import torch
import matplotlib.pyplot as plt
import torch.nn as nn
from scipy import stats
import datasets

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device',device)


# set paths
root_output = 'output/'   # where to save trained models
root_results = 'eval_result/'  # folder where to save results
root_data = 'data/'       # where the datasets are

data_in = None
data_out = None
data_name = None


def load_test_data(name):
    """
    Loads the dataset. Has to be called before anything else.
    :param name: string, the dataset's name
    """
    # normalization



    assert isinstance(name, str), 'Name must be a string'
    global data_in, data_out, data_name

    if data_name == name:
        return

    elif name == 'earth_inv':
        with open(datasets.root + 'train_data.npy', 'rb') as f:
            x_data = np.load(f)
            y_data = np.load(f)

    else:
        raise ValueError('Unknown dataset')
    
    data_in = x_data    
    data_out = y_data
    data_name = name

    return np.shape(data_in)[1], np.shape(data_out)[1]



def is_data_loaded():
    """
    Checks whether a dataset has been loaded.
    :return: boolean
    """
    return data_name is not None



def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """

    if not os.path.exists(folder):
        os.makedirs(folder)




def load_checkpoint(filepath,dim_x,dim_y):
    """
    Load checkpoint
    """
    checkpoint = torch.load(filepath)
    model = NF_Net(dim_x,dim_y).to(device)
    model.load_state_dict(checkpoint['state_dict'])
    return model


def load_model(dim_x,dim_y,model_name):
    """
    Load model
    """

    assert is_data_loaded(), 'Dataset hasn\'t been loaded'

    savedir = root_output
    filename = model_name

    print(savedir + filename + '.pt')
    device = torch.device("cuda")
    model = load_checkpoint(savedir + filename + '.pt', dim_x,dim_y)
    model.to(device)
    model.eval()
    return model




class NF_Net(nn.Module):

    def __init__(self, dim_in, dim_out):
        super(NF_Net, self).__init__()

        self.dim = dim_in + dim_out
        self.x_dim = dim_in
        self.y_dim = dim_out
        self.hid_size = 512

        self.input = nn.Linear(self.dim, self.hid_size)
        self.fc1= nn.Linear(self.hid_size,self.hid_size)
        self.output = nn.Linear(self.hid_size,self.y_dim)

        self.inv_input = nn.Linear(self.dim, self.hid_size)
        self.inv_fc1= nn.Linear(self.hid_size,self.hid_size)
        self.inv_output = nn.Linear(self.hid_size,self.y_dim)


    def backward(self, x):

        y0 = x[:, 0:self.x_dim]
        x = torch.tanh(self.inv_input(x))
        x = torch.tanh(self.inv_fc1(x))
        x = self.inv_output(x)
        x = torch.cat((y0, x), 1)
        return x



def test_marginal(name):

    savedir = 'evalresult/' + name + '/'
    make_folder(savedir)

    print('test dataset is {0}...'.format(name))
    dim_in, dim_out = load_test_data(name)

    print('dimensionality of input and output are ', dim_in, dim_out)
    try:
        NF = load_model(dim_in,dim_out,name)

    except IOError:
        return 'N/A'

    static_name = 'data/mean_std.npy'
    with open(static_name, 'rb') as f:
        mu_x = np.load(f)
        s_x = np.load(f)
        mu_y = np.load(f)
        s_y = np.load(f)

    ## test:
    N_test = np.shape(data_in)[0]
    y0 = (data_in- mu_x)/s_x
    z_sample0 = np.random.randn(N_test,dim_out)
    y0z_sample0 = np.column_stack( (y0,z_sample0) )

    y0z_sample = torch.as_tensor(y0z_sample0,dtype=torch.float,device = device)

    y0_y = NF.backward(y0z_sample)
    y = y0_y[:,dim_in:]
    y_pred = y.to('cpu').detach().numpy()   # approximation

    y_pred = s_y * y_pred + mu_y






    ytrue = np.load('pre_latent.npy')
    y_rm = np.where(np.abs(np.std(ytrue, axis=0)-0.)<1e-5)[0]
    y_rm_ori = y_rm
    y_rm = y_rm - np.arange(5)
    print(y_rm)
    y_pred = np.insert(y_pred,y_rm,ytrue[:,y_rm_ori],axis=1)

    plt.figure(figsize=(20, 15))
    plt.subplots_adjust(hspace=0.5)
    for ii in range(20):
        ax = plt.subplot(4,5,ii+1)
        # ax.hist(y_pred[:,ii] - data_out[:,ii])
        ax.hist(y_pred[:,ii])


    print(y_pred.shape)

    plt.savefig('testapprox.png', bbox_inches="tight", dpi=300)

    with open('pre_latent_approx.npy', 'wb') as f:
        np.save(f, y_pred)


    



def main():


    for initial in sys.argv[1:]:

        if initial == 'earth_inv':
            test_marginal(initial)


        else:
            print('{0} is not a test initial'.format(initial))
            continue


if __name__ == '__main__':
    main()
