import numpy as np
import datasets

savedir = 'data/analyforward_gaussian_cov/'
class ANALYFORWARDCOV:

    class Data:

        def __init__(self, data):

            self.x = data.astype(np.float64)
            self.N = self.x.shape[0]

    def __init__(self):

        x_trn, x_val, y_trn, y_val,coeff = load_data_normalised()

        self.x_trn = self.Data(x_trn)
        self.x_val = self.Data(x_val)

        self.y_trn = self.Data(y_trn)
        self.y_val = self.Data(y_val)

        self.x_dims = self.x_trn.x.shape[1]
        self.y_dims = self.y_trn.x.shape[1]

        self.coeff = coeff
       


def load_data():
    with open(datasets.root + 'analyforward_gaussian_cov/train_data.npy', 'rb') as f:
        x_data = np.load(f)
        y_data = np.load(f)
        coeff = np.load(f)

    return x_data,y_data,coeff


def load_data_split():

    rng = np.random.RandomState(42)

    x_data,y_data,coeff = load_data()
    N = x_data.shape[0]

    r_indexes = np.arange(N)
    rng.shuffle(r_indexes)
    x_data = x_data[r_indexes]
    y_data = y_data[r_indexes]

    mu_x = x_data.mean(axis=0)
    s_x = x_data.std(axis=0)

    mu_y = y_data.mean(axis=0)
    s_y = y_data.std(axis=0)

    with open(savedir + 'mean_std.npy', 'wb') as f:
        np.save(f, mu_x)
        np.save(f, s_x)
        np.save(f, mu_y)
        np.save(f, s_y)


    N_validate = int(0.2*N)
    x_validate = x_data[-N_validate:]
    x_train = x_data[0:-N_validate]

    y_validate = y_data[-N_validate:]
    y_train = y_data[0:-N_validate]

    return x_train, x_validate, mu_x, s_x, y_train, y_validate, mu_y, s_y, coeff


def load_data_normalised():

    x_train, x_validate, mu_x, s_x, y_train, y_validate, mu_y, s_y, coeff = load_data_split()

    x_train = (x_train - mu_x)/s_x
    x_validate = (x_validate - mu_x)/s_x

    y_train = (y_train - mu_y)/s_y
    y_validate = (y_validate - mu_y)/s_y

    
    return  x_train, x_validate, y_train, y_validate, coeff
