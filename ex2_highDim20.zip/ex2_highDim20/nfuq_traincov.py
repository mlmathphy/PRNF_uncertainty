import torch
import torch.nn as nn
import numpy as np
import torch.optim as optim
import matplotlib.pyplot as plt
import datasets
import math
import os

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print('device',device)

root_output = 'output/'   # where to save trained models
root_data = 'data/'      # where the datasets are

data = None
data_name = None

seed = 12345
torch.manual_seed(seed)
np.random.seed(seed)


def load_data(name):
    """
    Loads the dataset. Has to be called before anything else.
    :param name: string, the dataset's name
    """

    assert isinstance(name, str), 'Name must be a string'
    datasets.root = root_data
    global data, data_name

    if data_name == name:
        return

    if name == 'analyforward_gaussian_cov':
        data = datasets.ANALYFORWARDCOV()
        data_name = name


    else:
        raise ValueError('Unknown dataset')

def is_data_loaded():
    """
    Checks whether a dataset has been loaded.
    :return: boolean
    """
    return data_name is not None


def data_loader(data,batch_size):
    x_trn = torch.as_tensor(data.x_trn.x,dtype=torch.float,device = device)
    x_val = torch.as_tensor(data.x_val.x,dtype=torch.float,device = device)

    y_trn = torch.as_tensor(data.y_trn.x,dtype=torch.float,device = device)
    y_val = torch.as_tensor(data.y_val.x,dtype=torch.float,device = device)


    data_trn = torch.hstack((x_trn,y_trn))
    data_val = torch.hstack((x_val,y_val))


    train_loader = torch.utils.data.DataLoader(dataset=data_trn, 
                                            batch_size=batch_size, 
                                            shuffle=True)
    valid_loader = torch.utils.data.DataLoader(dataset=data_val, 
                                            batch_size=batch_size, 
                                            shuffle=False)
    
    return train_loader, valid_loader



def make_folder(folder):
    """
    Creates given folder (or path) if it doesn't exist.
    """
    if not os.path.exists(folder):
        os.makedirs(folder)



def save_model(model, model_name):
    """
    Save pytorch NN model.
    """

    assert is_data_loaded(), 'Dataset hasn\'t been loaded'
    
    savedir = root_output
    make_folder(savedir)

    filename = model_name
    checkpoint = {'state_dict': model.state_dict()}
    torch.save(checkpoint, savedir + filename + '.pt')

def jacobian(output,input,dim_x):

    n, dim= input.shape
    dim_y = dim-dim_x
    w = torch.ones_like(input[:,[0]])

    jacob1 = torch.empty(dim_y, n, dim)
    input1 = input
    output1 = output[:,dim_x:dim]

    for i in range(dim_y):
        output1_i = output1[:, [i]]
        jacob1[i] = torch.autograd.grad(output1_i, input1, w, create_graph=True)[0]
        
    jacob1 = jacob1.permute(1, 0, 2)
    jacob1 = jacob1[:,:,dim_x:dim]
    return jacob1


class NF_Net(nn.Module):

    def __init__(self, dim_x, dim_y):
        super(NF_Net, self).__init__()

        self.dim = dim_x + dim_y
        self.x_dim = dim_x
        self.y_dim = dim_y
        self.hid_size = 512

        self.input = nn.Linear(self.dim, self.hid_size)
        self.fc1= nn.Linear(self.hid_size,self.hid_size)
        self.output = nn.Linear(self.hid_size,self.y_dim)

        self.inv_input = nn.Linear(self.dim, self.hid_size)
        self.inv_fc1= nn.Linear(self.hid_size,self.hid_size)
        self.inv_output = nn.Linear(self.hid_size,self.y_dim)


    def forward(self, x):

        x0 = x[:, 0:self.x_dim]

        x = torch.tanh(self.input(x))
        x = torch.tanh(self.fc1(x))
        x = self.output(x)
        x = torch.cat((x0, x), 1)
        return x


    def backward(self, x):

        x0 = x[:, 0:self.x_dim]
        x = torch.tanh(self.inv_input(x))
        x = torch.tanh(self.inv_fc1(x))
        x = self.inv_output(x)
        x = torch.cat((x0, x), 1)
        return x


    def get_grad(self, x):
     
        x.requires_grad_(True)
        xx = self.forward(x)
        jac = jacobian(xx,x,self.x_dim)
        return jac


def standard_normal_logprob(z):
    logZ = -0.5 * math.log(2 * math.pi)
    return logZ - z.pow(2) / 2

def loss_fun(model, y, dim_x, dim_y, C_rev):
    dim = dim_x + dim_y
    NF = model.to(device)
    z = NF.forward(y)

    ## loss1: forward loss:
    loss1 = - 1.0 * torch.mean( torch.sum(standard_normal_logprob(z[:,dim_x:dim]), axis = 1, keepdim=False), axis = 0 )

    ## loss2: det of jacobian
    _, R_Jac = torch.linalg.qr(NF.get_grad(y))
    trace_value = torch.log( torch.abs( torch.diagonal(R_Jac.to(device), 0, dim1=1, dim2=2) ) )
    # print(trace_value)
    loss2 =  - torch.mean( torch.sum(trace_value, axis = 1), axis = 0)


    ## loss3: backward loss
    y_pred = NF.backward(z)
    loss3 = torch.mean( (y_pred[:,dim_x:dim] - y[:,dim_x:dim])**2 )

    # print(loss1, loss2, loss3)
    loss = loss1 * 1.0 + loss2 * 1.0 + loss3 * C_rev

    # print(loss,loss1,loss2,loss3)
    return loss



def eval_logmean(model, dataloader, dim_x, dim_y, c_rev):
    num_val = 0.0
    losses = 0.0
    for y_valid in dataloader:
        num_val = num_val + y_valid.shape[0]
        y_valid = y_valid.to(device)

        losses = losses + loss_fun(model, y_valid, dim_x,dim_y, c_rev) * y_valid.shape[0]
        
    losses = losses / num_val
    return losses





# ------------------------------------------------
#                The main routine
# ------------------------------------------------
# The index of the function
example = "analyforward_gaussian_cov"
model_name = example
print(example)
savedir = 'trainresult/' + example + '/'
make_folder(savedir)

plt.figure()

C_rev = 80
batch_size = 1000
n_iter = 250


load_data(example)
assert is_data_loaded(), 'Dataset hasn\'t been loaded'

dim_x = int(data.x_dims)
dim_y = int(data.y_dims)
dim = dim_x + dim_y
print('dimensionality of input is ', dim_x)
print('dimensionality of output is ', dim_y)


NF = NF_Net(dim_x,dim_y).to(device)
NF.zero_grad()



## Learning rate
learning_rate = 0.005
optimizer = optim.Adam(NF.parameters(), lr=learning_rate)

## loading data
train_loader, valid_loader = data_loader(data, batch_size)
static_name = 'data/' + example  + '/mean_std.npy'
with open(static_name, 'rb') as f:
    mu_x = np.load(f)
    s_x = np.load(f)
    mu_y = np.load(f)
    s_y = np.load(f)

## testing 
Ntest = 20000
x_test = 0.5*np.ones(dim_x) # choose from [0,1]
# true solution
y_true = np.matmul(x_test,data.coeff)
# print(y_true)

x_test = np.tile(x_test,(Ntest,1))
x_test = (x_test - mu_x)/s_x
z = np.random.randn(Ntest,dim_y)
x0_z = np.hstack((x_test,z))
x0_z = torch.as_tensor(x0_z,dtype=torch.float,device = device)
# print(x0_z.shape)


## error record
error_record = np.empty((0,3), float)


## loop
for i in range(n_iter):



    if i > 50:
        optimizer.param_groups[0]["lr"] = 0.002

    if i > 100:
        optimizer.param_groups[0]["lr"] = 0.001

    if i > 150:
        optimizer.param_groups[0]["lr"] = 0.0005

    if i > 200:
        optimizer.param_groups[0]["lr"] = 0.0002

    if i % 10 == 0:
        print('iteration step: ' + '{0:1d}'.format(i))
        print('learning rate: ' + '{0:6f}'.format(optimizer.param_groups[0]["lr"]))

        for ii, train_sample_ii in enumerate(train_loader):
            train_sample_ii = train_sample_ii.to(device)

            loss = loss_fun(NF, train_sample_ii, dim_x, dim_y, C_rev)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print(i,ii,loss)


        # validation loss
        valid_loss = eval_logmean(NF, valid_loader, dim_x, dim_y, C_rev)
        print('valid loss', valid_loss)


        # testing point mean adn std 
        x0_y = NF.backward(x0_z)
        y = x0_y[:,dim_x:dim]
        y_pred = y.to('cpu').detach().numpy()
        y_pred = s_y * y_pred + mu_y
        # print(np.mean(y_pred,axis=0))
        # print(np.std(y_pred,axis=0))
  

        mean_iter = np.linalg.norm(np.mean(y_pred,axis=0)-y_true)
        print("error of mean is ", mean_iter)





        
    else:
        for ii, y_sample_ii in enumerate(train_loader):
            y_sample_ii = y_sample_ii.to(device)
            loss = loss_fun(NF, y_sample_ii, dim_x, dim_y, C_rev)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()




save_model(NF, model_name)



exit()






















